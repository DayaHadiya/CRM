<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\HomeController;
use App\Http\Controllers\admin\IncomeController;
use App\Http\Controllers\admin\CategoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', function () {
    return redirect('/login');
})->name('index');

Route::get('/login',  [HomeController::class, 'login'])->name('login');
Route::post('/login',  [HomeController::class, 'submitlogin'])->name('submitlogin');
Route::get('/logout',  [HomeController::class, 'logout'])->name('logout');

Route::group(['middleware' => 'auth:admin'], function(){

Route::get('/dashboard',  [HomeController::class, 'dashboard'])->name('dashboard');

Route::get('/setting',  [HomeController::class, 'setting'])->name('setting');
Route::post('/setting',  [HomeController::class, 'change'])->name('changesetting');

Route::get('/category',  [CategoryController::class, 'manage'])->name('category');
Route::post('/category',  [CategoryController::class, 'add'])->name('add.category');
Route::get('/category/{type}',  [CategoryController::class, 'filter'])->name('filter.category');
Route::get('/categoryfilter/{number}',  [CategoryController::class, 'filterByNumber'])->name('filternumber.category');
Route::post('/editcategory',  [CategoryController::class, 'edit'])->name('edit.category');
Route::get('/deletecategory/{id}',  [CategoryController::class, 'delete'])->name('delete.category');

Route::get('/income',  [IncomeController::class, 'manage'])->name('income');
Route::post('/income',  [IncomeController::class, 'add'])->name('add.income');
Route::post('/editincome',  [IncomeController::class, 'edit'])->name('edit.income');
Route::get('/deleteincome/{id}',  [IncomeController::class, 'delete'])->name('delete.income');
Route::get('/filterincome',  [IncomeController::class, 'filter'])->name('filter.income');
Route::get('/incomeDatefilter/{date}',  [IncomeController::class, 'filterByDate'])->name('filterdate.income');
Route::get('/incomeNumberfilter/{number}',  [IncomeController::class, 'filterByNumber'])->name('filternumber.income');

}); 
