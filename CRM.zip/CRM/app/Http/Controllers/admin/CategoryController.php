<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Validator;
use Illuminate\Pagination\Paginator;

class CategoryController extends Controller
{
	private $pagination = 10;

    public function manage()
    {
    	$data = Category::query()->paginate($this->pagination);
    	return view('admin.category',compact('data'));
    }

    public function add(Request $request)
    {
    	$input = $request->all();
    	$validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
        if ($validator->fails()) { 
            return redirect()->back()->withInput()->withErrors($validator->messages());
        }

        $input['name'] = $input['cat_name'];
        $input['type'] = $input['cat_type'];
        $input['status'] = 1;

        $category = Category::create($input);
        return redirect()->route('admin.category');

    }

    public function edit(Request $request)
    {
        $input = $request->all();

        $validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
        if ($validator->fails()) { 
            return redirect()->back()->withInput()->withErrors($validator->messages());
        }

        $update['name'] = $input['cat_name'];
        $update['type'] = $input['cat_type'];

        $category = Category::where('id',$input['id'])->update($update);
        return redirect()->route('admin.category');

    }

    public function delete($id)
    {
       Category::where('id',$id)->delete();
       return redirect()->route('admin.category');
    }

    public function filter($type)
    {
    	$data = Category::query()->where('type',$type)->paginate($this->pagination);
    	return view('admin.category',compact('data'));
    }

    public function filterByNumber($number)
    {
    	$data = Category::query()->limit($number)->get();
    	
    	return view('admin.category',compact('data'));
    }

    private function getRules($type, $input) {
        $return = array();
        $return['cat_name'] = 'required';
        $return['cat_type'] = 'required';
        return $return;
    }

    private function messages() {
        return [
            'cat_name.required'  => 'The category name field is required.',
            'cat_type.required'  => 'The category type field is required.'
        ];
    }
}
