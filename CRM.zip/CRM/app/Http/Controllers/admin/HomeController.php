<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use App\Models\Income;
use Validator;

class HomeController extends Controller
{
    public function login()
    {
    	return view('admin.login');
    }

    public function submitlogin(Request $request)
    {
    	try {
            $validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
            if ($validator->fails()) { 
                return redirect()->back()->withInput()->withErrors($validator->messages());
            }
            if (Auth::guard('admin')->attempt(['email' => $request->username, 'password' => $request->password], $request->get('remember'))) {
                return redirect()->route('admin.dashboard');
            }

            return redirect()->back()->withInput()->withErrors(['Invalid email or password.']);
        } catch (RuntimeException $ex) {
            return redirect()->back()->withInput()->withErrors([$ex->getMessage()]);
        }
    }

    public function dashboard()
    {
        $incomeMonthly = Income::whereMonth('date', date('m'))->sum('amount');
        $incomeYearly = Income::whereYear('date', date('Y'))->sum('amount');
        
    	return view('admin.dashboard',compact('incomeYearly','incomeMonthly'));
    }

    public function setting(Request $request)
    {
        return view('admin.setting');
    }

    public function change(Request $request)
    {
        $input = $request->all();
        $update = array();
        if(isset($input['user_name']))
        {
            $update['username'] = $input['user_name'];
        }
        if(isset($input['password']))
        {
            $update['password'] = bcrypt($input['password']);
        }
        Admin::where('id',Auth::user()->id)->update($update);
        return redirect()->route('admin.setting');
    }


    public function logout() {
        Auth::logout();
        return redirect()->route('admin.login');
    }


   

    private function getRules($type, $input) {
        $return = array();
        $return['username'] = 'required|max:50';
        $return['password'] = 'required|max:20';
        return $return;
    }

    private function messages() {
        return [
            'username.required'  => 'The Email field is required.',
            'password.required'  => 'The Password field is required.'
        ];
    }
}
