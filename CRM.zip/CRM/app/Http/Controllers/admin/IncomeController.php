<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Income;
use Validator;
use Illuminate\Pagination\Paginator;

class IncomeController extends Controller
{
	private $pagination = 10;

    public function manage()
    {
    	$data = Income::select('incomes.*','users.name as uname','categories.name as cname')
    						->join('users','incomes.payer','users.id')
    						->join('categories','incomes.cat_id','categories.id')
    						->paginate($this->pagination);
    	$total = $data->sum('amount');
    	return view('admin.income',compact('data','total'));
    }

    public function add(Request $request)
    {
    	$input = $request->all();
    	$validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
        if ($validator->fails()) { 
            return redirect()->back()->withInput()->withErrors($validator->messages());
        }

        $input['amount'] = $input['amount'];
        $input['date'] = $input['t_date'];
        $input['payer'] = $input['payer_payer'];
        $input['cat_id'] = $input['category'];
        $input['method'] = $input['method'];
        $input['status'] = $input['status'];
        $input['description'] = $input['description'];

        $category = Income::create($input);
        return redirect()->route('admin.income');

    }

    public function edit(Request $request)
    {
        $input = $request->all();
        //dd($input);
        $validator = Validator::make( $request->all(), $this->getRules('Add', $request->all()), $this->messages());
        if ($validator->fails()) { 
            return redirect()->back()->withInput()->withErrors($validator->messages());
        }

        $update['amount'] = $input['amount'];
        $update['date'] = $input['t_date'];
        $update['payer'] = $input['payer_payer'];
        $update['cat_id'] = $input['category'];
        $update['method'] = $input['method'];
        $update['status'] = $input['status'];
        $update['description'] = $input['description'];

        $income = Income::where('id',$input['id'])->update($update);
        return redirect()->route('admin.income');

    }

    public function delete($id)
    {
       Income::where('id',$id)->delete();
       return redirect()->route('admin.income');
    }

    public function filter(Request $request)
    {
    	$input = $request->all();
    	$data = Income::select('incomes.*','users.name as uname','categories.name as cname')
    						->join('users','incomes.payer','users.id')
    						->join('categories','incomes.cat_id','categories.id')
    						->where('incomes.cat_id',$input['category'])
    						->where('incomes.payer',$input['payer_payer'])
    						->where('incomes.method',$input['method'])
    						->where('incomes.status',$input['status'])
    						->paginate($this->pagination);

    	$total = $data->sum('amount');

    	return view('admin.income',compact('data','total'));
    }

    public function filterByNumber($number)
    {
    	$data = Income::select('incomes.*','users.name as uname','categories.name as cname')
    						->join('users','incomes.payer','users.id')
    						->join('categories','incomes.cat_id','categories.id')
    						->limit($number)
    						->paginate($this->pagination);
    	
    	$total = $data->sum('amount');
    	return view('admin.income',compact('data','total'));
    }

    public function filterByDate($date)
    {
    	$month = date('m', strtotime($date));
    	$data = Income::select('incomes.*','users.name as uname','categories.name as cname')
    						->join('users','incomes.payer','users.id')
    						->join('categories','incomes.cat_id','categories.id')
    						->whereMonth('incomes.date', $month)
    						->paginate($this->pagination);
    	
    	$total = $data->sum('amount');
    	return view('admin.income',compact('data','total'));
    }

    private function getRules($type, $input) {
        $return = array();
        $return['amount'] = 'required';
        $return['t_date'] = 'required';
        $return['payer_payer'] = 'required';
        $return['category'] = 'required';
        $return['method'] = 'required';
        $return['status'] = 'required';
        $return['description'] = 'required';
        return $return;
    }

    private function messages() {
        return [
            'amount.required'  => 'The amount field is required.',
            't_date.required'  => 'The date field is required.',
            'payer_payer.required'  => 'The payer field is required.',
            'category.required'  => 'The category field is required.',
            'method.required'  => 'The method field is required.',
            'status.required'  => 'The status field is required.',
            'description.required'  => 'The description field is required.',
        ];
    }
}
