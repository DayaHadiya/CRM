<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncomesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incomes', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('cat_id')->unsigned()->index()->nullable();
            $table->foreign('cat_id')->references('id')->on('catogories')->onDelete('cascade');
            $table->string('amount','100');
            $table->date('date');
            $table->bigInteger('payer')->unsigned()->index()->nullable();
            $table->foreign('payer')->references('id')->on('users')->onDelete('cascade');
            $table->string('method','100');
            $table->string('description');
            $table->string('status','50')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incomes');
    }
}
