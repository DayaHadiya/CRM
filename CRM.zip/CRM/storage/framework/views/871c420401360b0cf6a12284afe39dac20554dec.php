<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon">
                <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Kit Account</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php if(Route::currentRouteName() == 'admin.dashboard') { ?> active <?php } ?>">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php if(Route::currentRouteName() == 'admin.income') { ?> active <?php } ?>">
                <a class="nav-link" href="<?php echo e(route('admin.income')); ?>">
                    <i class="fas fa-fw fa-money-bill-alt"></i>
                    <span>Incomes</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <!-- <li class="nav-item ">
                <a class="nav-link" href="expenses.html">
                    <i class="fas fa-fw fa-shopping-cart"></i>
                    <span>Expenses</span>
                </a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php if(Route::currentRouteName() == 'admin.category') { ?> active <?php } ?>">
                <a class="nav-link" href="<?php echo e(route('admin.category')); ?>">
                    <i class="fas fa-fw fa-tags"></i>
                    <span>Categories</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php if(Route::currentRouteName() == 'admin.setting') { ?> active <?php } ?>">
                <a class="nav-link" href="<?php echo e(route('admin.setting')); ?>">
                <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
        </ul>
        <!-- End of Sidebar --><?php /**PATH C:\xampp\CRM\resources\views/admin/include/sidebar.blade.php ENDPATH**/ ?>