
<?php 
    $title = "Income | Kit Account ";  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>
    

    <!-- Begin Page Content -->
    <div class="container-fluid"><!-- Page Heading -->
        <h1 class="h3 mb-4 text-primary">Incomes
            <div class="d-inline-block">
                <a href="#" class="btn btn-primary">Cleard: <span class="badge text-primary bg-white">$ <?php echo e($total); ?></span></a>
            </div>
            <div class="float-right">
                <button class="btn btn-light text-primary" type="button" data-toggle="modal" data-target="#filterModel"><i class="fa fa-fw fa-filter"></i> Filter By</button>
                <div class="dropdown d-inline-block">
                    <button class="btn btn-light dropdown-toggle text-primary" type="button" id="ddMonth" data-toggle="dropdown" aria-expanded="false">
                        <i class="fa fa-fw fa-calendar"></i> Apr 2023
                    </button>
                    <div class="dropdown-menu" aria-labelledby="ddMonth">
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeDatefilter/'.'Apr 2023')); ?>">Apr 2023</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeDatefilter/'.'Mar 2023')); ?>">Mar 2023</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeDatefilter/'.'Feb 2023')); ?>">Feb 2023</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeDatefilter/'.'Jan 2023')); ?>">Jan 2023</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeDatefilter/'.'All Months')); ?>">All Months</a>
                    </div>
                </div>
                <div class="dropdown d-inline-block">
                    <button class="btn btn-light dropdown-toggle text-primary" type="button" id="ddPage" data-toggle="dropdown" aria-expanded="false">10</button>
                    <div class="dropdown-menu" aria-labelledby="ddPage">
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeNumberfilter/'.'10')); ?>">10</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeNumberfilter/'.'30')); ?>">30</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeNumberfilter/'.'50')); ?>">50</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeNumberfilter/'.'80')); ?>">80</a>
                        <a class="dropdown-item" href="<?php echo e(url('admin/incomeNumberfilter/'.'100')); ?>">100</a>
                    </div>
                </div>
                <a class="btn btn-primary" href="#" data-toggle="modal" data-target="#transactionModel">
                    <i class="fas fa-plus"></i> Add New
                </a>
            </div>
        </h1>
        <?php if($errors->any()): ?>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div style="color:red"><?php echo e($error); ?></div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <!-- Transaction list -->
        <table class="table bg-white rounded overflow-hidden shadow">
            <thead>
                <tr>
                    <th style="width: 85px;" class="text-center">Date</th>
                    <th style="width: 125px;">Amount</th>
                    <th style="width: 200px;">Payer</th>
                    <th style="width: 200px;">Category</th>
                    <th style="width: 160px;">Method</th>
                    <th>Description</th>
                    <th style="width: 85px;" class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $count=0; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count++; ?>
                <tr >
                    <td class="text-center"><?php echo e(date('d-M', strtotime($d->date))); ?></td>
                    <td>$ <?php echo e($d->amount); ?></td>
                    <td><?php echo e($d->uname); ?></td>
                    <td><?php echo e($d->cname); ?></td>
                    <td><?php echo e($d->method); ?></td>                        
                    <td><span><?php echo e($d->description); ?></span></td>
                    <td class="action_td text-center">
                        <!--Edit link-->
                        <a href="#" data-toggle="modal" class="text-primary edit-transaction-link" data-transaction-id='<?php echo e($d->id); ?>' data-income='{"id":"<?php echo e($d->id); ?>","amount":"<?php echo e($d->amount); ?>","t_date":"<?php echo e($d->date); ?>","payer_payer":"<?php echo e($d->payer); ?>","category":<?php echo e($d->cat_id); ?>,"method":"<?php echo e($d->method); ?>","status":"<?php echo e($d->status); ?>","description":"<?php echo e($d->description); ?>"}' onClick="editTransaction(this)"><i class="far fa-edit"></i></a>
                        <!--EOF Edit link-->
                        <!--Delete link-->
                        <a onclick="return confirm('Are you sure you want to delete?');" class="text-primary" href="<?php echo e(url('/admin/deleteincome/'.$d->id)); ?>"><i class="far fa-trash-alt"></i></a>
                        <!--EOF Delete link-->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- EOF Transaction list -->

        <!-- Pagination -->
        <nav aria-label="Page navigation example">
            <?php echo e($data->render()); ?>

            <!-- <ul class="pagination">
                <li class="page-item text-primary disabled">
                    <a class="page-link " href="" tabindex="-1" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                    </a>
                </li>
                        <li class="page-item active">
                    <a class="page-link  bg-gradient-primary" href="#">1</a>
                </li>
                        <li class="page-item ">
                    <a class="page-link  text-primary" href="#">2</a>
                </li>
                        <li class="page-item text-primary">
                    <a class="page-link text-primary" href="#" tabindex="-1" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only">Next</span>
                    </a>
                </li>
            </ul> -->
        </nav>
        <!-- EOF Pagination -->

        <!-- Add New / Edit Form Model -->
        <form id="addEditForm" action="<?php echo e(route('admin.add.income')); ?>" method="post">
            <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
            <input type="hidden" name="id" >
            <div class="modal fade" id="transactionModel" tabindex="-1" role="dialog" aria-labelledby="transactionModelLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title text-primary" id="transactionModelLabel"><span>Add New</span> Incomes</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Fields -->

                            <div class="row">
                                <div class="col-lg-6 form-group">
                                    <label for="amount">Amount:</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-dollar-sign"></i></span>
                                        </div>
                                        <input type="text" class="form-control" id="amount" name="amount" required="true" />
                                    </div>
                                </div>
                                <div class="col-lg-6 form-group">
                                    <label for="t_date">Date:</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-fw fa-calendar"></i></span>
                                        </div>
                                        <input type="date" class="form-control" id="t_date" name="t_date" required="true" />
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="row">
                                        <?php $payer =  App\Models\User::get(); ?>
                                        <div class="col-lg-6 form-group">
                                            <label for="addNewPayerPayer">Payer:</label>
                                            <select class="form-control" id="addNewPayerPayer" name="payer_payer" required="true" >
                                                <option value="">Select Payer</option>
                                                <?php $__currentLoopData = $payer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-lg-6 form-group">
                                            <?php $cat =  App\Models\Category::where('type','income_category')->get(); ?>
                                            <label for="addNewCategory">Income Category:</label>
                                            <select class="form-control " id="addNewCategory" name="category" required="true" >
                                                <option value="">Select Income Category</option>
                                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 form-group">
                                    <label for="method">Method:</label>
                                    <select class="form-control " id="method" name="method" required="true" >
                                        <option>Select Method</option>
                                        <option value="cash">cash</option>
                                        <option value="check">check</option>
                                        <option value="credit card">credit card</option>
                                        <option value="debit">debit</option>
                                        <option value="electronic transfer">electronic transfer</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 form-group">
                                    <label for="status">Status:</label>
                                    <select class="form-control " id="status" name="status" required="true" >
                                        <option>Select Status</option>
                                        <option value="uncleared">uncleared</option>
                                        <option value="cleard">cleard</option>
                                        <option value="reconciled">reconciled</option>
                                        <option value="void">void</option>
                                    </select>
                                </div>
                                <div class="col-lg-12 form-group">
                                    <label for="description">Description:</label>
                                    <textarea class="form-control" id="description" name="description" style="max-width: 100%; min-width: 100%;" required="true"></textarea>
                                </div>
                            </div>
                            <!-- EOF Fields -->
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-fw fa-times"></i> Close</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <!-- EOF Add New / Edit Form Model -->

        <!-- Filter Modal -->
        <form action="<?php echo e(route('admin.filter.income')); ?>" method="get">
            <div class="modal fade" id="filterModel" tabindex="-1" role="dialog" aria-labelledby="filterModelLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title text-primary" id="filterModelLabel">Filter By</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Fields -->
                            <div class="form-group">
                                <?php $cat =  App\Models\Category::where('type','income_category')->get(); ?>
                                <label for="filterCategory">Income Category:</label>
                                <select class="form-control chosen-select load-by-ajax income_category" id="filterCategory" name="category">
                                    <option value="">Select Income Category</option>
                                     <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <?php $payer =  App\Models\User::get(); ?>

                                <label for="filterPayerPayer">Payer:</label>
                                <select class="form-control Payer chosen-select load-by-ajax payer" id="filterPayerPayer" name="payer_payer">
                                    <option value="">Select Payer</option>
                                        <?php $__currentLoopData = $payer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="filterMethod">Method:</label>
                                <select class="form-control chosen-select" id="filterMethod" name="method">
                                    <option value="">Select Method</option>
                                    <option  value="cash">Cash</option>
                                    <option  value="check">Check</option>
                                    <option  value="credit card">Credit card</option>
                                    <option  value="debit">Debit</option>
                                    <option  value="electronic transfer">Electronic Transfer</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="filterStatus">Status:</label>
                                <select class="form-control chosen-select" id="filterStatus" name="status">
                                    <option value="">Select Status</option>
                                    <option  value="uncleared">Uncleared</option>
                                    <option  value="cleard">Cleard</option>
                                    <option  value="reconciled">Reconciled</option>
                                    <option  value="void">Void</option>
                                </select>
                            </div>
                            <!-- EOF Fields -->
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-fw fa-times"></i> Close</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-filter"></i> Filter</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <!-- EOf Filter Modal -->


    </div>
    <!-- /.container-fluid -->
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\CRM\resources\views/admin/income.blade.php ENDPATH**/ ?>