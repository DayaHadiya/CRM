
<?php 
    $title = "Category | Kit Account";  
?>
<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('content'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid"><!-- Page Heading -->
            <h1 class="h3 mb-4 text-primary">Categories

                <div class="float-right">
                    <div class="dropdown d-inline-block">
                        <button class="btn btn-light dropdown-toggle text-primary" type="button" id="ddPage" data-toggle="dropdown" aria-expanded="false" name="filterByNumber">10</button>
                        <div class="dropdown-menu" aria-labelledby="ddPage">
                            <a class="dropdown-item" href="<?php echo e(url('admin/categoryfilter/'.'1')); ?>">10</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/categoryfilter/'.'30')); ?>">30</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/categoryfilter/'.'50')); ?>">50</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/categoryfilter/'.'80')); ?>">80</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/categoryfilter/'.'100')); ?>">100</a>
                        </div>
                    </div>
                    <div class="dropdown d-inline-block">
                        <button class="btn btn-light dropdown-toggle text-primary" type="button" id="categoryTypes" data-toggle="dropdown" aria-expanded="false" name="filterByCategory">Category</button>
                        <div class="dropdown-menu" aria-labelledby="categoryTypes">
                            <a class="dropdown-item" href="<?php echo e(url('admin/category/'.'income_category')); ?>">Income Category</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/category/'.'expense_category')); ?>">Expense Category</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/category/'.'payer')); ?>">Payer</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/category/'.'payee')); ?>">Payee</a>
                        </div>
                    </div>
                    
                </div>
            </h1>

             <?php if($errors->any()): ?>
                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div style="color:red"><?php echo e($error); ?></div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
            <div class="row">
                <!-- form -->
                <div class="col-md-4">
                    <div class="card mb-5 overflow-hidden shadow">
                        <div class="card-header"> Add New Category</div>
                        <div class="card-body">
                            <form id="addCatForm" action="<?php echo e(route('admin.add.category')); ?>" method="post">
                                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label for="categoryName">Category Name*</label>
                                        <input type="text" class="form-control" id="categoryName" name="cat_name" value="" required />
                                    </div>
                                    <div class="form-group col-12">
                                        <label for="catType">Category Type*</label>
                                        <select class="form-control" name="cat_type" id="catType" required>
                                            <option value="">Select Category Type</option>
                                            <option value="income_category">Income Category</option>
                                            <option value="expense_category">Expense Category</option>
                                            <option value="payer">Payer</option>
                                            <option value="payee">Payee</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Save</button>
                                        <button type="reset" class="btn btn-secondary"><i class="fas fa-undo"></i> Clear</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- EOF form -->
            
                <!-- data -->
                <div class="col-md-8">
                    <!-- Categories list -->
                    <table class="table bg-white rounded overflow-hidden shadow">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center" style="width: 50px;">#</th>
                                <th scope="col">Name</th>
                                <th scope="col" style="width: 160px;">Type</th>
                                <th scope="col" class="text-center" style="width: 85px;">Status</th>
                                <th scope="col" class="text-center" style="width: 85px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=0; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $count++; ?>
                                <tr>
                                    <td scope="row" class="text-center"><?php echo e($count); ?></td>
                                    <td><?php echo e($d->name); ?></td>
                                    <td><?php echo e($d->type); ?></td>
                                    <?php if($d->status == 1): ?>
                                        <td class="text-center"><a class="text-primary" href="#"><i class="fas fa-check-circle"></i></a></td>
                                    <?php else: ?>
                                        <td class="text-center"><a class="text-primary" href="#"><i class="far fa-check-circle"></i></a></td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <a class="text-primary" href="#" data-category='{"cat_id":"<?php echo e($d->id); ?>","cat_name":"<?php echo e($d->name); ?>","cat_type":"<?php echo e($d->type); ?>","cat_parent":"0"}' onclick="editCategory(this); return false;"><i class="far fa-edit"></i></a>
                                        <a class="text-primary" onclick="return confirm('Are you sure you want to delete this Category?');" href="<?php echo e(url('/admin/deletecategory/'.$d->id)); ?>">
                                            <i class="far fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <tr>
                                <td scope="row" class="text-center">1</td>
                                <td>Category Name</td>
                                <td>Expense Category</td>
                                <td class="text-center"><a class="text-primary" href="#"><i class="fas fa-check-circle"></i></a></td>
                                <td class="text-center">
                                    <a class="text-primary" href="#" data-category='{"cat_id":"230","cat_name":"Category Name","cat_type":"payer","cat_parent":"0"}' onclick="editCategory(this); return false;"><i class="far fa-edit"></i></a>
                                    <a class="text-primary" onclick="return confirm('Are you sure you want to delete this Category?');" href="#">
                                        <i class="far fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td scope="row" class="text-center">1</td>
                                <td>Category Name</td>
                                <td>Payer</td>
                                <td class="text-center"><a class="text-primary" href="#"><i class="far fa-check-circle"></i></a></td>
                                <td class="text-center">
                                    <a class="text-primary" href="#" data-category='{"cat_id":"230","cat_name":"Category Name","cat_type":"payer","cat_parent":"0"}' onclick="editCategory(this); return false;"><i class="far fa-edit"></i></a>
                                    <a class="text-primary" onclick="return confirm('Are you sure you want to delete this Category?');" href="#">
                                        <i class="far fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td scope="row" class="text-center">1</td>
                                <td>Category Name</td>
                                <td>Payee</td>
                                <td class="text-center"><a class="text-primary" href="#"><i class="fas fa-check-circle"></i></a></td>
                                <td class="text-center">
                                    <a class="text-primary" href="#" data-category='{"cat_id":"230","cat_name":"Category Name","cat_type":"payer","cat_parent":"0"}' onclick="editCategory(this); return false;"><i class="far fa-edit"></i></a>
                                    <a class="text-primary" onclick="return confirm('Are you sure you want to delete this Category?');" href="#">
                                        <i class="far fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr> -->
                        </tbody>
                    </table>
                    <!-- EOF User list -->
                    
                    <!-- Categories Pagination -->
                    <nav aria-label="Page navigation example">
                        <?php echo e($data->render()); ?>

                        <!-- <ul class="pagination">
                            <li class="page-item text-primary disabled">
                                <a class="page-link " href="" tabindex="-1" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link  bg-gradient-primary" href="#">1</a>
                            </li>
                            <li class="page-item ">
                                <a class="page-link  text-primary" href="#">2</a>
                            </li>
                            <li class="page-item text-primary">
                                <a class="page-link text-primary" href="#" tabindex="-1" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </li>
                        </ul> -->
                    </nav>
                    <!-- Categories Pagination -->
                </div>
                <!-- EOF data -->
            </div>
            
            
            <!-- Edit Category Model-->
            <form id="editForm" action="<?php echo e(route('admin.edit.category')); ?>" method="post">
                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                
                <div class="modal fade" id="editCategoryModel" tabindex="-1" role="dialog" aria-labelledby="editCategoryLabel" aria-hidden="true">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-primary" id="editCategoryLabel">Edit Category</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <!-- Fields -->
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label for="editCategoryName">Category Name*</label>
                                        <input type="text" class="form-control" id="editCategoryName" name="cat_name" value="" required />

                                        <label for="catType">Category Type*</label>
                                        <select class="form-control" name="cat_type" id="editCategoryType" required>
                                            <option value="">Select Category Type</option>
                                            <option value="income_category">Income Category</option>
                                            <option value="expense_category">Expense Category</option>
                                            <option value="payer">Payer</option>
                                            <option value="payee">Payee</option>
                                        </select>

                                        <input type="hidden" class="form-control" id="editCategoryId" name="id" value="" required />
                                    </div>

                                    <!-- <div id="editParentCategoryCol" class="form-group col-12 mb-0">
                                        <input id="editparentCategoryhidden" type="hidden" name="cat_parent" value="0">
                                    </div> -->
                                </div>
                                <!-- EOF Fields -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-fw fa-times"></i> Close</button>
                                <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Save</button>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
            <!-- EOF Edit Category Model-->

        </div>
        <!-- /.container-fluid -->
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.default.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\CRM\resources\views/admin/category.blade.php ENDPATH**/ ?>