@extends('admin.default.master')
<?php 
    $title = "Setting | Kit Account ";  
?>
@section('title', $title )
@section('content')
		
		<div class="container-fluid"><!-- Page Heading -->
                    <h1 class="h3 mb-4 text-primary">Settings</h1>

                    

                    <div class="row">
                        <!-- form -->
                        <div class="col-md-6">
                            <div class="card mb-5 overflow-hidden shadow">
                                <div class="card-header">
                                    General Settings
                                </div>
                                <div class="card-body">
                                    <form action="{{ route('admin.changesetting') }}" method="post">
                                    	<input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <div class="row">
                                            <div class="form-group col-4">
                                                <label for="user_name">Login User Name*</label>
                                            </div>
                                            <div class="form-group col-8">
                                                <input type="text" class="form-control" id="user_name" name="user_name" value="{{ Auth::user()->username}}" require />
                                            </div>
                    
                                            <div class="form-group col-4">
                                                <label for="password">Login Password</label>
                                            </div>
                                            <div class="form-group col-8">
                                                <input type="password" class="form-control" id="password" name="password" value="" />
                                            </div>
                    
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Save</button>
                                                <button type="reset" class="btn btn-secondary"><i class="fas fa-undo"></i> Clear</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- EOF form -->
                    </div>





                </div>

@endsection