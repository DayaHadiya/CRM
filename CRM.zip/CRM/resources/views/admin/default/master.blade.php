
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>@yield('title')</title>
    <link rel="shortcut icon" type="image/png" href="assets/img/favicon.ico"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="{{ asset('admin/assets/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <style>
        .chosen-container.chosen-container-single {
            width: 100% !important;
        }
        .chosen-container-single .chosen-single {
            background: none !important;
            height: calc(1.5em + 0.75rem + 2px) !important;
            padding: 0.375rem 0.75rem !important;
            font-size: 1rem !important;
            font-weight: 400 !important;
            line-height: 1.5 !important;
            color: #6e707e !important;
            background-clip: padding-box !important;
            border: 1px solid #d1d3e2 !important;
            border-radius: 0.35rem !important;
            box-shadow: none !important;
        }
        .chosen-container-active.chosen-with-drop .chosen-single div b {
            background-position: -18px 10px;
        }
        .chosen-container-single .chosen-single div b {
            background-position: 0 10px;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        @include('admin.include.sidebar')
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            @include('admin.include.header')

            @yield('content')
            </div>
            <!-- End of Page Wrapper -->
            <!-- Scroll to Top Button-->
            @include('admin.include.footer')
        </div>
            <!-- End of Content Wrapper -->

    </div>
        <!-- End of Page Wrapper -->
           <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="{{ route('admin.logout') }}">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>
     <script>
        jQuery(document).ready(function($){

            $(".chosen-select").chosen({
                no_results_text: "Oops, nothing found!"
            }); 
    
            $('#transactionModel').on('hide.bs.modal', function (event) {
                $(".edit-transaction-link").html('<i class="far fa-edit"></i>');
                $("#addEditForm").trigger("reset");
                $('#addEditForm input[name="id"]').remove();            
                $("#addEditForm select option").removeAttr("selected");
                var modal = $(this)
                $('input[name="action"]').val("add");
                modal.find('.modal-title span').text('Add New');
                $('.chosen-select').trigger("chosen:updated");
            });    
        });
    
        function editTransaction( element ) {
            jQuery(document).ready(function($){
                $(element).html('<div class="spinner-grow spinner-grow-sm text-primary" style="height: 18px;width: 18px;" role="status"><span class="sr-only">Loading...</span></div>');
                var transactionId = $(element).attr("data-transaction-id");
                if( !transactionId ) {
                    alert("transaction ID not found");
                    return;
                }
                var data = $(element).attr("data-income");
                if( !data ) {
                    alert("income data not found");
                    return;
                }
                var form = document.getElementById("addEditForm");

                form.action = "{{route('admin.edit.income')}}"; 
                const income = JSON.parse( data );
    
                $('#addEditForm input[name="id"]').val(income.id);
                $('#addEditForm input[name="amount"]').val(income.amount);
                $('#addEditForm input[name="t_date"]').val(income.t_date);
                $('#addEditForm select[name="payer_payer"]').val(income.payer_payer);
                $('#addEditForm select[name="category"]').val(income.category);
                $('#addEditForm select[name="method"]').val(income.method);
                $('#addEditForm select[name="status"]').val(income.status);
                $('#addEditForm input[name="description"]').text(income.description);

                var modal = $('#transactionModel')
                modal.find('.modal-title span').text('Edit ');
                modal.modal('show');
            });
        }
    </script>
    <script>
        var parent_expense_categories = [];
        jQuery(document).ready(function($){
    
            $('#addCatForm select[name="cat_type"]').on("change", function(){
                let value = $(this).val();
                if( 'expense_category' == value ) {
                    $("#addCatForm #parentCategoryCol").html('<label for="parentCategory">Parent Category</label><select class="form-control" name="cat_parent" id="parentCategory"><option value="">Select Parent Category</option></select>');
                    bind_cat_parent( parent_expense_categories );
                    $("#addCatForm #parentCategoryCol").removeClass("mb-0");
                } else {
                    $("#addCatForm #parentCategoryCol").html('<input id="parentCategoryhidden" type="hidden" name="cat_parent" value="0">');
                    $("#addCatForm #parentCategoryCol").addClass("mb-0");
                }
            });
    
            $('#addCatForm').on('reset', function(e) {
                $("#addCatForm #parentCategoryCol").html('<input id="parentCategoryhidden" type="hidden" name="cat_parent" value="0">');
                $("#addCatForm #parentCategoryCol").addClass("mb-0");
            });
    
            $('#editCategoryModel').on('hide.bs.modal', function (event) {
                $("#editForm").trigger("reset");           
                $("#editForm select option").removeAttr("selected");
                var modal = $(this)
            })
        });
    
        function bind_cat_parent( data ) {
            jQuery(document).ready(function($){
                var html = '<option value="">Select Parent Category</option>';
                for (const category_index in data) {
                    html+= '<option value="'+data[category_index].cat_id+'">'+data[category_index].cat_name+'</option>';
                }
                $('select[name="cat_parent"]').html(html);
            });
        }
    
        function editCategory( element ) {
            jQuery(document).ready(function($){
                var data = $(element).attr("data-category");
                if( !data ) {
                    alert("category data not found");
                    return;
                }
                

                const category = JSON.parse( data );
    
                $('#editForm input[name="id"]').val(category.cat_id);
                $('#editForm input[name="cat_name"]').val(category.cat_name);
                $('#editForm select[name="cat_type"]').val(category.cat_type);
                if( category.cat_type == "expense_category" ) {
                    $("#editParentCategoryCol").html('<label for="editParentCategory">Parent Category</label><select class="form-control" name="cat_parent" id="editParentCategory"><option value="">Select Parent Category</option></select>');
                    $("#editParentCategoryCol").prev().removeClass("mb-0");
                    bind_cat_parent( parent_expense_categories );
                } else {
                    $("#editParentCategoryCol").html("");
                    $("#editParentCategoryCol").prev().addClass("mb-0");
                }
                
                setTimeout(function() {
                    var cat_parent = category.cat_parent;
                    if( cat_parent != "0" ) {
                        $('#editForm select[name="cat_parent"] option').each( function() {
                            if( $(this).val() == cat_parent ) {
                                $(this).attr("selected", "selected");
                            }
                        });
                    }
                }, 100);
    
                var modal = $('#editCategoryModel');
                modal.modal('show');
            });
        }
    </script>
    
</body>
</html>